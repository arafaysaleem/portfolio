#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <errno.h>
#include <time.h>

#define IPSpace 100000
#define simRun 4
#define simTime 1000
#define scanRate 5

typedef enum {empty, vulnerable, infected} NodeType;

NodeType NodeStatus[IPSpace + 1];
NodeType PriorNodeStatus[IPSpace + 1];
int lt[simRun+1][simTime+1];
int TimeScanNodes[simTime+1];

void initializeNodeStatus() {
    for (int i = 1; i <= IPSpace; i++) {
        if ((i % 1000 <= 10) && (i % 1000 > 0)) { // if in range of 1..10 make it vulnerable
            NodeStatus[i] = vulnerable;
            PriorNodeStatus[i] = vulnerable;
        } else {
            NodeStatus[i] = empty; // else empty
            PriorNodeStatus[i] = empty;
        }
    }
    NodeStatus[2010] = infected; // initial victim
    PriorNodeStatus[2010] = infected;
}

void initializeTimeScanNodes() {
    for (int i = 0; i < simTime; i++) {
        TimeScanNodes[i] = 0; // reset all times (t=0..simTime) infected count's to 0
    }
}

void initializeLt() {
    for (int i = 1; i <= simRun; i++) {
        for (int j = 1; j <= simTime; j++) {
            lt[i][j] = 0; // reset the results for next strategy
        }
    }
}

void saveResultsToFile(int strategy) {
    // generate filename based on strategy
    char fileName[30];
    snprintf(fileName, sizeof(fileName), "results-strategy_%d.csv", strategy);
    
    FILE *file = fopen(fileName, "w");
    if (file == NULL) {
        printf("Error opening file!\n");
        return;
    }

    // Write header rows
    fprintf(file, ",");
    for (int j = 1; j <= simTime; j++) {
        fprintf(file, "Tick(t),");
    }
    fprintf(file, "\n");
    fprintf(file, "Simulation Run,");
    for (int j = 1; j <= simTime; j++) {
        fprintf(file, "%d,", j);
    }
    fprintf(file, "\n");

    // Write data
    int infectionTimes[simRun+1];
    for (int i = 1; i <= simRun; i++) {
        fprintf(file, "Run %d,", i);
        bool allInfected = false;
        for (int j = 1; j <= simTime; j++) {
            // Replace 0 with 1000 once all infected to maintain flat graph
            if (lt[i][j] == 1000 && !allInfected) {
                allInfected = true;
                infectionTimes[i] = j;
            }
            if (allInfected) {
                fprintf(file, "1000,");
            } else {
                fprintf(file, "%d,", lt[i][j]);
            }
        }
        fprintf(file, "\n");
    }
    
    // Write infection times
    fprintf(file, "\nRun #,Full-Infection Tick(t)\n");
    for (int i = 1; i <= simRun; i++) {
        fprintf(file, "Run %d,%d\n", i, infectionTimes[i]);
    }
    
    fclose(file);
}

double uniformRandom() {
    double temp = (double)(rand()+0.5) / ((double)(RAND_MAX) + 1.0);
    return temp;
}

int getRandomIp(int strategy) {
    int randomIP;
    if (strategy == 1) {
        // Strategy 1: Generate a random IP between 1 and IPSpace
        randomIP = rand() % IPSpace + 1;
    } else {
        // Strategy 2: Generate a random IP based on the uniform random number
        if (uniformRandom() <= 0.7) {
            // Option 1: Pick a random value y such that y is in [x-10, x+10]
            int x = rand() % IPSpace + 1;
            randomIP = (x - 10) + rand() % 21;  // Generate a random y in [x-10, x+10]
            if (randomIP < 1) randomIP = 1;  // Ensure randomIP is at least 1
            if (randomIP > IPSpace) randomIP = IPSpace;  // Ensure randomIP is at most IPSpace
        } else {
            // Option 2: Pick a random IP value y between 1 and IPSpace
            randomIP = rand() % IPSpace + 1;
        }
    }
    return randomIP;
}

int main() {
    for (int strategy = 1; strategy <= 2; strategy++) { // Run for both strategies
        initializeLt(); // reset lt for next strategy
    
        srand(time(NULL));
        for (int sim = 1; sim <= simRun; sim++) { // run 4 simulations
            initializeNodeStatus(); // reset the IP statuses
            initializeTimeScanNodes(); // reset the scan status
            int infectedNum = 1; // first victim
            TimeScanNodes[1] = 1; // start scanning at t=1
            lt[sim][1] = 1; // one infected already at t=1
    
            for (int t = 1; t <= simTime; t++) { // run for t..simTime
                if (infectedNum == 1000) break; // All vulnerable IPs infected
                int readyToScan = TimeScanNodes[t]; // Get how many IPs will perform scanning
    
                for (int scan = 1; scan <= readyToScan * scanRate; scan++) { // run for 1..(# of scanning IPs * 5 scan per IP)
                    
                    int randomIP = getRandomIp(strategy); // get ip based on strategy
                    
                    if (PriorNodeStatus[randomIP] == vulnerable) { // prior holds the current t statuses
                        PriorNodeStatus[randomIP] = infected; // mark infected
                        NodeStatus[randomIP] = infected; // mark infected for t+1
                        infectedNum++;
                        TimeScanNodes[t+50]++; // delay scanning
                        if (infectedNum == 1000) break; // if all affected, don't scan anymore
                    }
                }
    
                lt[sim][t+1] = infectedNum; // mark all infected in next tick i.e. t+1
                TimeScanNodes[t+1] += readyToScan; // carry forward the current scanners + delayed scanner to next tick
                for (int i = 1; i <= IPSpace; i++) { 
                    PriorNodeStatus[i] = NodeStatus[i]; // copy all statuses to previous before changing tick
                }
            }
    
            if (infectedNum < 1000) { // if ticks are over but not all infected, count is too low
                printf("simTime=%d isn't enough to infect all, only infected infectedNum=%d\n", simTime, infectedNum);
                break;
            }
        }
  
      saveResultsToFile(strategy); // save results to csv
    }
    
    return 0;
}
