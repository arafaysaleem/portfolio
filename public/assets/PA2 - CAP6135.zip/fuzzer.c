#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

// Function to mutate the buffer
void mutateBuffer(char* mutatedBuf, int buffSize, int n, const char* startFrom, const char* replaceStrat, const char* replaceBy) {
    int j, position;
    int startByte;
    
    if (strcmp(startFrom, "any") == 0) {
      startByte = rand() % buffSize; // Random start
    } else if (strcmp(startFrom, "first") == 0) {
      startByte = 0; // From beginning
    }
    
    for (j = startByte; j < (n + startByte); j++) {
        // Generate position
        if (strcmp(replaceStrat, "random") == 0) {
            position = rand() % buffSize; // Random position
        } else if (strcmp(replaceStrat, "consecutive") == 0) {
            position = j; // Consecutive position
        }

        // Mutate the image
        if (strcmp(replaceBy, "by double") == 0) {
            mutatedBuf[position] = (double)rand(); // Replace by random double
        } else if (strcmp(replaceBy, "by int") == 0) {
            mutatedBuf[position] = rand() % 256; // Replace by random int
        } else if (strcmp(replaceBy, "by 0") == 0) {
            mutatedBuf[position] = 0; // Replace by 0
        } else if (strcmp(replaceBy, "by 255") == 0) {
            mutatedBuf[position] = 255; // Replace by 255
        }
    }
}

int main(void)
{
	int fuzzNum = 500;
  int buffSize = 1000;
	char buffer[buffSize];
  char mutatedBuf[buffSize];
  int bugCounter = 0;
	int status, ret, i, j, retCode;
	int position;
	time_t t;
  FILE* fileOut;
	
	srand((unsigned) time(&t));  // randomize the initial seed
 
  FILE* fileIn = fopen("./cross.jpg", "rb");
	if (fileIn == NULL) {
    perror("Error opening file");
    return 1;
  }
  
  // Read the file content into the buffer
  fread(buffer, 1, sizeof(buffer), fileIn);
  fclose(fileIn); // Close the file
  
	for(i=0; i<fuzzNum; i++){	
    // Copy data from the original buffer to the mutable buffer
    memcpy(mutatedBuf, buffer, buffSize);
    
    // Set parameters
    const char* startFrom = "any"; // "any" or "first"
    int n = 20;
    const char* replaceStrat = "random"; // "random" or "consecutive"
    const char* replaceBy = "by int"; // "by double", "by int", "by 0", or "by 255"

    // Call the mutateBuffer function
    mutateBuffer(mutatedBuf, buffSize, n, startFrom, replaceStrat, replaceBy);
    
    // output the mutated test file
    fileOut = fopen("mutated.jpg", "wb");
    fwrite(mutatedBuf, 1, sizeof(mutatedBuf), fileOut);
    fclose(fileOut);
		
		ret = system("./jpeg2bmp mutated.jpg mutated.bmp\n");
		wait(&status); // wait for the jpeg2bmp program to finish
		retCode = WEXITSTATUS(ret); 
		if (retCode == 128+11 || retCode ==128+6)  // the target code caused segmentation fault (11) or Abort (6)
		{
      // generate filename based on bug
      char fileName[30];
      snprintf(fileName, sizeof(fileName), "test-%d.jpg", bugCounter);
      bugCounter++;
      
      // output the mutated test file with name
      fileOut = fopen(fileName, "wb");
      fwrite(mutatedBuf, 1, sizeof(mutatedBuf), fileOut);
      fclose(fileOut);
      
      // append msg after bug info
      fprintf(stderr, "file %s is generated\n", fileName);
		}
	}
   return 0;
}
